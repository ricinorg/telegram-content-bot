# Telegram Content Bot — diagnostic image version

This version is prepared for Render Web Service and adds detailed, stage-specific Telegram errors.

Build command:
`unzip -o telegram-content-bot-image-v3-diagnostic.zip && pip install -r telegram-content-bot/requirements.txt`

Start command:
`cd telegram-content-bot && python bot.py`

Environment variables:
- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_CHANNEL_ID`
- `OPENAI_API_KEY`
- `OPENAI_TEXT_MODEL=gpt-5.6-luna`
- `OPENAI_IMAGE_MODEL=gpt-image-2`
- `ADMIN_USER_IDS` (optional)
- `TIMEZONE=UTC`
- `DATABASE_PATH=data/bot.db`
- `LOG_LEVEL=INFO`

Render Web Service should provide `RENDER_EXTERNAL_URL`. The bot checks it at startup.

Diagnostics:
- `/status` shows configuration presence and model names without secrets.
- `/newpost` reports the exact stage: text, image, save/preview, or publish.
- Secrets are masked before exception details are sent to Telegram.
