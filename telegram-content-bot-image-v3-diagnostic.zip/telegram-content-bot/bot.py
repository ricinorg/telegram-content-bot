import logging
import os
from pathlib import Path

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
)

from ai import AIService
from config import load_settings
from db import Database

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger(__name__)

settings = load_settings()
db = Database(settings.database_path)
ai = AIService(
    settings.openai_api_key,
    settings.openai_text_model,
    settings.openai_image_model,
)

IMG = Path("data/images")
IMG.mkdir(parents=True, exist_ok=True)


def ok(uid):
    return not settings.admin_user_ids or uid in settings.admin_user_ids


def kb(i):
    return InlineKeyboardMarkup(
        [[
            InlineKeyboardButton("✅ انتشار", callback_data=f"publish:{i}"),
            InlineKeyboardButton("🗑 رد", callback_data=f"reject:{i}"),
        ]]
    )


def safe_error_text(exc):
    """Turn an exception into a useful Telegram diagnostic without exposing secrets."""
    msg = str(exc)
    if settings.openai_api_key:
        msg = msg.replace(settings.openai_api_key, "[OPENAI_API_KEY_HIDDEN]")
    if settings.telegram_bot_token:
        msg = msg.replace(settings.telegram_bot_token, "[TELEGRAM_BOT_TOKEN_HIDDEN]")
    if len(msg) > 1800:
        msg = msg[:1800] + "\n…"
    return msg


async def start(u: Update, c: ContextTypes.DEFAULT_TYPE):
    if u.effective_user and ok(u.effective_user.id):
        await u.message.reply_text(
            "سلام! 🤖\n\n"
            "دستور ساخت پست:\n"
            "/newpost موضوع\n\n"
            "برای بررسی تنظیمات امن ربات:\n"
            "/status"
        )


async def help_command(u: Update, c: ContextTypes.DEFAULT_TYPE):
    if u.effective_user and ok(u.effective_user.id):
        await u.message.reply_text(
            "/start\n"
            "/newpost موضوع برای تولید متن و تصویر\n"
            "/status برای بررسی تنظیمات ربات"
        )


async def status_command(u: Update, c: ContextTypes.DEFAULT_TYPE):
    if not u.effective_user or not ok(u.effective_user.id):
        return

    webhook = bool(os.getenv("RENDER_EXTERNAL_URL"))
    lines = [
        "🔎 وضعیت ربات",
        "",
        f"✅ TELEGRAM_BOT_TOKEN: {'تنظیم شده' if settings.telegram_bot_token else '❌ خالی'}",
        f"✅ TELEGRAM_CHANNEL_ID: {settings.telegram_channel_id}",
        f"✅ OPENAI_API_KEY: {'تنظیم شده' if settings.openai_api_key else '❌ خالی'}",
        f"📝 مدل متن: {settings.openai_text_model}",
        f"🎨 مدل تصویر: {settings.openai_image_model}",
        f"🌐 RENDER_EXTERNAL_URL: {'تنظیم شده' if webhook else '❌ پیدا نشد'}",
        "",
        "این دستور کلیدها را نمایش نمی‌دهد.",
    ]
    await u.message.reply_text("\n".join(lines))


async def new_post(u: Update, c: ContextTypes.DEFAULT_TYPE):
    if not u.effective_user or not ok(u.effective_user.id):
        return

    topic = " ".join(c.args).strip()
    if not topic:
        await u.message.reply_text("مثال: /newpost درباره هوش مصنوعی")
        return

    status = await u.message.reply_text("⏳ مرحله ۱ از ۳: در حال ساخت متن...")

    try:
        text = ai.generate_text(topic)
    except Exception as exc:
        log.exception("TEXT_GENERATION_FAILED")
        await status.edit_text(
            "❌ خطا در مرحله ۱: ساخت متن\n\n"
            f"🔴 جزئیات:\n{safe_error_text(exc)}\n\n"
            "اگر عکس این پیام را بفرستی، دقیقاً می‌گویم چه چیزی را باید اصلاح کنیم."
        )
        return

    await status.edit_text("✅ متن ساخته شد.\n\n⏳ مرحله ۲ از ۳: در حال ساخت تصویر...")

    try:
        data = ai.generate_image(topic, text)
    except Exception as exc:
        log.exception("IMAGE_GENERATION_FAILED")
        await status.edit_text(
            "❌ خطا در مرحله ۲: ساخت تصویر\n\n"
            f"🔴 جزئیات:\n{safe_error_text(exc)}\n\n"
            f"📝 مدل متن: {settings.openai_text_model}\n"
            f"🎨 مدل تصویر: {settings.openai_image_model}\n\n"
            "متن با موفقیت ساخته شده؛ مشکل فقط در بخش تصویر است."
        )
        return

    try:
        path = IMG / f"post_{os.urandom(8).hex()}.png"
        path.write_bytes(data)
        i = db.create_post(topic, text, str(path))
        await status.delete()

        with path.open("rb") as f:
            await u.message.reply_photo(
                f,
                caption=f"🎨 تصویر پیشنهادی پست #{i}",
            )

        await u.message.reply_text(
            f"📝 پیش‌نمایش پست #{i}\n\n{text}",
            reply_markup=kb(i),
        )
    except Exception as exc:
        log.exception("SAVE_OR_PREVIEW_FAILED")
        await status.edit_text(
            "❌ خطا در مرحله ۳: ذخیره/نمایش پست\n\n"
            f"🔴 جزئیات:\n{safe_error_text(exc)}"
        )


async def callback(u: Update, c: ContextTypes.DEFAULT_TYPE):
    q = u.callback_query
    await q.answer()

    if not q.from_user or not ok(q.from_user.id):
        return

    try:
        action, i = q.data.split(":")
        i = int(i)
    except Exception:
        await q.edit_message_text("❌ درخواست نامعتبر است.")
        return

    post = db.get_post(i)
    if not post:
        await q.edit_message_text("❌ پست پیدا نشد.")
        return

    if action == "reject":
        try:
            db.update_post(i, "rejected")
            await q.edit_message_text(f"🗑 پست #{i} رد شد.")
        except Exception as exc:
            log.exception("REJECT_FAILED")
            await q.edit_message_text(
                "❌ خطا در رد کردن پست\n\n"
                f"🔴 جزئیات:\n{safe_error_text(exc)}"
            )
        return

    if action == "publish":
        try:
            if post[3] and Path(post[3]).exists():
                with Path(post[3]).open("rb") as f:
                    await c.bot.send_photo(
                        chat_id=settings.telegram_channel_id,
                        photo=f,
                    )

            await c.bot.send_message(
                chat_id=settings.telegram_channel_id,
                text=post[2],
            )
            db.update_post(i, "published")
            await q.edit_message_text(
                f"✅ پست #{i} همراه تصویر منتشر شد."
            )
        except Exception as exc:
            log.exception("PUBLISH_FAILED")
            await q.edit_message_text(
                "❌ خطا در مرحله انتشار\n\n"
                f"🔴 جزئیات:\n{safe_error_text(exc)}\n\n"
                "اگر متن خطا را بفرستی، دقیقاً مشخص می‌کنیم مشکل از ربات، کانال یا دسترسی تلگرام است."
            )


def main():
    url = os.getenv("RENDER_EXTERNAL_URL", "").rstrip("/")
    if not url:
        raise RuntimeError(
            "RENDER_EXTERNAL_URL تنظیم نشده است؛ این متغیر برای Webhook لازم است."
        )

    app = Application.builder().token(settings.telegram_bot_token).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("status", status_command))
    app.add_handler(CommandHandler("newpost", new_post))
    app.add_handler(CallbackQueryHandler(callback))

    app.run_webhook(
        listen="0.0.0.0",
        port=int(os.getenv("PORT", "10000")),
        url_path="telegram",
        webhook_url=f"{url}/telegram",
        allowed_updates=Update.ALL_TYPES,
        drop_pending_updates=False,
    )


if __name__ == "__main__":
    main()
