import base64
from openai import OpenAI


class AIServiceError(RuntimeError):
    """Safe, user-facing error with a stage name."""


class AIService:
    def __init__(self, key, text_model, image_model):
        self.client = OpenAI(api_key=key)
        self.text_model = text_model
        self.image_model = image_model

    def generate_text(self, topic):
        prompt = f"""برای کانال تلگرامی فارسی @nova_ip درباره موضوع زیر یک پست خلاقانه بنویس:
{topic}
قوانین قطعی:
- لحن دوستانه، صمیمی و انسانی.
- شروع با قلاب ذهنی قوی و کنجکاوکننده.
- متن نسبتاً طولانی، ارزشمند و خوانا، با پاراگراف‌های مناسب و ایموجی متعادل.
- حتماً @nova_ip داخل متن باشد.
- حتماً یک سؤال مشخص از اعضای کانال بپرس.
- در پایان 5 تا 10 هشتگ مرتبط با موضوع قرار بده.
- متن اختصاصی و خلاقانه باشد و کلیشه‌ای نباشد.
فقط متن نهایی را برگردان."""
        try:
            r = self.client.responses.create(model=self.text_model, input=prompt)
            text = (r.output_text or "").strip()
            if not text:
                raise RuntimeError("OpenAI پاسخ متنی خالی برگرداند.")
            return text
        except Exception as exc:
            raise AIServiceError(
                f"TEXT_GENERATION | مدل: {self.text_model} | {type(exc).__name__}: {exc}"
            ) from exc

    def generate_image(self, topic, text):
        prompt = f"""Create a creative, striking square social-media image for a Persian Telegram post.
Topic: {topic}
Context: {text[:2500]}
Use an original modern editorial composition, strong visual hook, cinematic lighting and rich detail.
Communicate the topic visually. No readable text, logos, usernames, watermarks or UI."""
        try:
            r = self.client.images.generate(
                model=self.image_model,
                prompt=prompt,
                size="1024x1024",
            )
            if not r.data or not getattr(r.data[0], "b64_json", None):
                raise RuntimeError("OpenAI پاسخ تصویر بدون داده تصویری برگرداند.")
            return base64.b64decode(r.data[0].b64_json)
        except Exception as exc:
            raise AIServiceError(
                f"IMAGE_GENERATION | مدل: {self.image_model} | {type(exc).__name__}: {exc}"
            ) from exc
