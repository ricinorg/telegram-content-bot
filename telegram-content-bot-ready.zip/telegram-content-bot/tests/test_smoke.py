def test_project_imports():
    import src
    assert src is not None
